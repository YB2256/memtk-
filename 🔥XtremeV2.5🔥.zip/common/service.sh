#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# Perf HAL
cat /proc/sys/kernel/perf_cpu_time_max_percent;
echo '5' > /proc/sys/kernel/perf_cpu_time_max_percent;
cat /proc/sys/kernel/sched_boost;
echo '1' > /proc/sys/kernel/sched_boost;
cat /proc/sys/kernel/timer_migration;
echo '0' > /proc/sys/kernel/timer_migration;

# Low Memory Killer ter op
stop perfd
echo '0' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo '80' > /proc/sys/vm/overcommit_ratio
echo '150' > /proc/sys/vm/vfs_cache_pressure
echo '0' > /proc/sys/vm/extra_free_kbytes
echo '128' > /proc/sys/kernel/random/read_wakeup_threshold
echo '1024' > /proc/sys/kernel/random/write_wakeup_threshold
echo '128' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '0' > /sys/block/mmcblk0/queue/iostats
echo '1' > /sys/block/mmcblk0/queue/add_random
echo '128' > /sys/block/mmcblk1/queue/read_ahead_kb
echo '0' > /sys/block/mmcblk1/queue/iostats
echo '1' > /sys/block/mmcblk1/queue/add_random
echo '4096' > /proc/sys/vm/min_free_kbytes
echo '0' > /proc/sys/vm/oom_kill_allocating_task
echo '5' > /proc/sys/vm/dirty_ratio
echo '20' > /proc/sys/vm/dirty_background_ratio
chmod 666 /sys/module/lowmemorykiller/parameters/minfree
chown root /sys/module/lowmemorykiller/parameters/minfree
echo '21816,29088,36360,43632,50904,65448' > /sys/module/lowmemorykiller/parameters/minfree
echo '1' > /proc/sys/vm/swappiness
rm /data/system/perfd/default_values
start perfd

# Touch switch
if [[ -e /sys/class/touch/switch ]]
then
	echo 7035 > /sys/class/touch/switch/set_touchscreen;
	echo 8002 > /sys/class/touch/switch/set_touchscreen;
	echo 11000 > /sys/class/touch/switch/set_touchscreen;
	echo 13060 > /sys/class/touch/switch/set_touchscreen;
	echo 14005 > /sys/class/touch/switch/set_touchscreen;
fi

# Fast Charging enable
echo '2000000' > /sys/module/qpnp_smbcharger/parameters/default_dcp_icl_ma;
echo '1800000' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp_icl_ma;
echo '2400000' > /sys/module/qpnp_smbcharger/parameters/default_hvdcp3_icl_ma;
echo '1800000' > /sys/module/dwc3_msm/parameters/hvdcp_max_current;
echo '2000000' > /sys/module/dwc3_msm/parameters/dcp_max_current;
echo '2000000' > /sys/module/phy_msm_usb/parameters/dcp_max_current;
echo '1800000' > /sys/module/phy_msm_usb/parameters/hvdcp_max_current;
echo '1200000' > /sys/module/qpnp_smb2/parameters/weak_chg_icl_ua;
fi

# This script will be executed in late_start service mode
# More info in the main Magisk thread